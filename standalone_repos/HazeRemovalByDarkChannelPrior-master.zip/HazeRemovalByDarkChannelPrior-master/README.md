## Image Haze Removal By Dark Channel Prior

It is a Java implementation of algorithms proposed in the [paper](http://kaiminghe.com/publications/pami10dehaze.pdf): Single Image Haze Removal Using Dark Channel Prior, published by Kaiming He on [PAMI](https://www.computer.org/web/tpami) 2011.

The dark channel prior dehazing is a simple but effective method to remove haze from a single input image. The dark channel prior is a kind of statistics of outdoor haze-free images. It is based on a key observation—most local patches in outdoor haze-free images contain some pixels whose intensity is very low in at least one color channel. Using this prior with the haze imaging model, it is able to directly estimate the thickness of the haze and recover a high-quality haze-free image.

##### Additional

The image showing method is obtain from the repository: [ImShow-Java-OpenCV](https://github.com/master-atul/ImShow-Java-OpenCV).

The original Matlab codes are put in this project too.


### Requirements

* [Java 1.8](http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html).

* [OpenCV](http://opencv.org/). To make the OpenCV can work with JAVA IDE like IntelliJ or Eclipse, you may need to follow the guidance of [OpenCV Java Tutorials](http://opencv-java-tutorials.readthedocs.io/en/latest/01-installing-opencv-for-java.html) to set up OpenCV for Java in your favorite IDE.

* [Guided Image Filtering](http://kaiminghe.com/eccv10/index.html), published by [Dr. Kaiming He](http://kaiminghe.com/index.html) on ECCV 2010, is a kind of edge-preserving smoothing operator like the popular bilateral filter, but has better behaviors near edges. The Java Implementation locates at utils package, and the paper is shown in this [link](http://kaiminghe.com/publications/eccv10guidedfilter.pdf).

### Results

##### Enhancement Example
<img src="README-images/tulips.png" width = "425" height = "400" align=center />  <img src="README-images/tulipsResult.png" width = "425" height = "400" align=center />

##### Feathering Example
<img src="README-images/toy.bmp" width = "283" height = "320" align=center />  <img src="README-images/toy-mask.bmp" width = "283" height = "320" align=center />  <img src="README-images/toyResult.png" width = "283" height = "320" align=center />

##### Flash Example
<img src="README-images/cave-flash.bmp" width = "283" height = "360" align=center />  <img src="README-images/cave-noflash.bmp" width = "283" height = "360" align=center />  <img src="README-images/flashResult.png" width = "283" height = "360" align=center />

##### Haze Removal Results
<img src="README-images/gugong.png" width = "425" height = "600" align=center />  <img src="README-images/gugongDehaze.png" width = "425" height = "600" align=center />

<img src="README-images/ny.png" width = "425" height = "320" align=center />  <img src="README-images/nyDehaze.png" width = "425" height = "320" align=center />

<img src="README-images/flags.png" width = "425" height = "500" align=center />  <img src="README-images/flagsDehaze.png" width = "425" height = "500" align=center />

<img src="README-images/train.png" width = "425" height = "320" align=center />  <img src="README-images/trainDehaze.png" width = "425" height = "320" align=center />
